package TestCases;
import org.testng.annotations.AfterTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import Pages.LoginPage;

public class chkTitle {
	static String driverPath = "D:\\";
    static WebDriver driver;	
    static LoginPage login;
    
/*@AfterTest
public void closeAll()
{
	driver.close();
}
  */  
    @Test(priority=0)
    public void init()
    {
    	System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/login");
		driver.manage().window().maximize();
		login = new LoginPage(driver);
		
			
    }
    
	@Test (priority=1)
	public void chkTitle_method() {
	//public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// creating object of LoginPage class
		  		
			String actualtitle = login.readTitle();
			
			
			assertEquals(actualtitle, "The Internet");
		
	}
	
	@Test (priority=2)
	public void chkPosUsername()
	{
		
			System.out.println("The position of username box is :" + login.getPositionOfUsernamebox());
			Assert.assertEquals("(198, 233)", "(198, 233)");
			
			
	}		
			
	@Test (priority=3)
	public void chkUsernameVisible()
	{
		
		boolean unvisible;
		
	    unvisible = login.isUsernameVisible();
		Assert.assertTrue(unvisible);
		
	}
	
	
	
	@Test (priority=4)
	public void isUsernameboxfound()
	{
          
          boolean isUN = login.isUsernameboxAvailable();
          Assert.assertEquals(true,isUN);
	}
	
	
	}


