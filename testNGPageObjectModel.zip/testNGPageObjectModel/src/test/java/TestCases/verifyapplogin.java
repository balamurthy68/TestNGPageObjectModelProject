/**
 * 
 */
package TestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import Pages.LoginPage;

public class verifyapplogin {
	static String driverPath = "D:\\";
	@Test
	public void verifylogin()
	{
	
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/login");
		driver.manage().window().maximize();
	// creating object of LoginPage class
		
		LoginPage login = new LoginPage(driver);
		
			login.typeusername("tomsmith1");
			login.typepassword("SuperSecretPassword!");
			
			login.clickLoginButton();
			
			String status = login.getLoginStatus();
			if (status.contains("You logged in"))
			{
				Assert.assertEquals("1", "1");
			}
			else
			{
			     Reporter.log("Incorrect Credentials. Negative Test case passed by not letting the user in.",true);
			     
			     Assert.assertEquals("1", "1");
						     
			}
	}
	
}
