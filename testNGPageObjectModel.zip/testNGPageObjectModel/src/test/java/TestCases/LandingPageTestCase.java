package TestCases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Pages.LandingPage;
import Pages.LoginPage;
import Setup.BasePage;
import junit.framework.Assert;


public class LandingPageTestCase extends BasePage {

  WebDriver driver;

  
  @BeforeClass

public void setup()
{
	driver=getDriver();
}

@Parameters({"p_username","p_password"})
	@Test
  public void  verifylogin(String un,String pw) {
	  
	LoginPage login=new LoginPage(driver);

	LandingPage lp = login.signIn(un, pw);
	
	boolean status = lp.verifyLogin("secure");
	
	Assert.assertEquals(status, true);
	
	}
}
