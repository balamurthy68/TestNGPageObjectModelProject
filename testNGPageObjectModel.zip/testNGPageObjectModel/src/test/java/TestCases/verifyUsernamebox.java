package TestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import Pages.LoginPage;

public class verifyUsernamebox {
	static String driverPath = "D:\\";
   @Test
	public void verifyUsernamebox_method() {
	//	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/login");
		driver.manage().window().maximize();
	// creating object of LoginPage class
		
		LoginPage login = new LoginPage(driver);
		
		boolean chkUsername=login.isUsernameboxAvailable();
		
		System.out.println(chkUsername);
	
	}

}
