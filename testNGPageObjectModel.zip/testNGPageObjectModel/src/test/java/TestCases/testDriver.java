package TestCases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;


public class testDriver extends Setup.driverManager{
  
	static WebDriver driver;
	
	
	@Test
  public void f () {
	  driver = this.initFirefox();
	  driver.get("http://www.yahoo.com");
 }
	
}

