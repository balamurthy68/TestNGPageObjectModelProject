package RegressionTests;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.relevantcodes.extentreports.ExtentTest;

import Setup.Calculator;



public class calcTest {
	ExtentReports extent;
	
	@BeforeSuite
	public void initExtentRep()
	{
		ExtentSparkReporter htmlReporter = new ExtentSparkReporter("target/extentReport.html");
		//create ExtentReports and attach reporter(s)
		 extent  = new ExtentReports();
		 extent.attachReporter(htmlReporter);
		
	}
	
	
	@BeforeClass()	
 public void ac()
 {
	 System.out.println("before secondclass");
 }
 
 @AfterClass()	
 public void ac1()
 {
	 System.out.println("After secondclass");
 }

 
	
 @Test(groups ="apitests")
  public void calcTestadd() {

	 Calculator c = new Calculator("Scientific");
	 //creates a toggle for the given test, add all log events under it
	  com.aventstack.extentreports.ExtentTest Calctest = extent.createTest("Calculator test", "Validate add in Calculator ");
	//initializing and starting the browser
		int actualval = c.add(10, 20);
		
		int expectedval = 30;

		System.out.println("In calcTest expected:"  + expectedval + " Actual:" + actualval);
		Assert.assertEquals(actualval, expectedval);
		
		Calctest.log(Status.PASS,"Calculator passed. expectedval:" + expectedval + " actual:" + actualval);
		extent.flush();
 }
}
