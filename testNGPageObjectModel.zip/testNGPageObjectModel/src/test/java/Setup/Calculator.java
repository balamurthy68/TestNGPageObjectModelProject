package Setup;

public class Calculator {

	public Calculator(String string) {
		// TODO Auto-generated constructor stub
		
		
	}

	public int add(int i, int j) {
		// TODO Auto-generated method stub
		
		
		return i +j;
		
		
	}
	
	public float add(int i, float j) {
		// TODO Auto-generated method stub
		
		
		return i +j;
		
		
	}

	public int add(int i, int j, int k) {
		// TODO Auto-generated method stub
		return i+j+k;
	}
	

}
