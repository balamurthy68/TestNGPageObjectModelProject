package Setup;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

public class BasePage {

	private WebDriver driver;
	
	public WebDriver getDriver()
	{
		return driver;
		
	}

	public void initialize(String browser,String url)
	{
		System.out.println("Initializing with "+ browser+ url);
		switch (browser) {
		case "chrome":
			System.setProperty("webdriver.chrome.driver", "d://chromedriver.exe");
			driver=new ChromeDriver();
			driver.get(url);
		    break;
		case "firefox":
			System.setProperty("webdriver.gecko.driver", "d://geckodriver.exe");
			driver=new FirefoxDriver();
			driver.get(url);
		    break;
		default:
			System.setProperty("webdriver.chrome.driver", "d://chromedriver.exe");
			
			driver=new ChromeDriver();
			driver.get(url);
		
		}
		
	}
	
	
	@BeforeClass
	@Parameters({"p_browser","p_url"})
	
	public void setup(String browser,String url)
	{
	
		System.out.println("in setup " + browser + "   " + url);
		initialize(browser,url);
	}
	
	@AfterClass
	public void teardown()
	{
		driver.quit();
	}
	
}

