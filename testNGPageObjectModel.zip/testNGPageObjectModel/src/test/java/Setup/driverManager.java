package Setup;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class driverManager {
	
	static WebDriver driver;
	
	public WebDriver initChrome()
	
	{
		System.setProperty("webdriver.chrome.driver", "d://chromedriver.exe");
		driver=new ChromeDriver();
		return driver;
	}
	
	public WebDriver initFirefox ()
	{
		System.setProperty("webdriver.gecko.driver", "d://geckodriver.exe");
		driver=new FirefoxDriver();
		return driver;
	}

	

}
