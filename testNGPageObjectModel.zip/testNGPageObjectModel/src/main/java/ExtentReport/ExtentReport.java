package ExtentReport;

import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExtentSparkReporter htmlReporter = new ExtentSparkReporter("extentReport.html");
	}

}
