package TestCases;

import org.testng.annotations.Test;



public class LandingPageTest{
  @Test
  public void f() {
	  
	  
  }
}
